Please make the m3 mounting holes countersunk as marked in user.drawings layer.
- Head diameter: 6.3 mm
- Hole diameter: 3.2 mm
- Countersunk angle: 90 degrees
- Locations marked in user layer (KiCad)

No components in pcb other then holes and traces