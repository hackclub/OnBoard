Project Name: IMU + Motor Driver 2
Project Version: #331d8f50
Project Url: https://www.flux.ai/maximagination/imu-plus-motor-driver-2

Project Description:
Inertial Measurement Unit (IMU) with MPU6050 IC and four-channel motor driver with N-MOSFETs for micro ESP32 drone.

XIAO Series - Modular Custom Add-on Board.


