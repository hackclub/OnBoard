---
name: "Pau Gomila"
slack_handle: "@pau_64_"
github_handle: "@Paugomilabarber"
tutorial: # https://jams.hackclub.com/batch/usb-hub/part-1 
https://jams.hackclub.com/batch/usb-hub/part-2 
wokwi: # Link to the Wokwi project if you're submitting for Hacky Holidays
---

# USB-HUB

<!-- This board has two USB outports and 1 input, so i can plug in twice the devices -->

<!-- 21.50 $ -->

<!-- Tell us a little bit about your design process. What were some challenges? What helped? ***Totally optional*** -->