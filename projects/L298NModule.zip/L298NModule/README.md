
---
name: "Ryan Wang"
slack_handle: "@Ffive44-1"
github_handle: "@Ffive44-1"
tutorial: # Link to the tutorial if you used one
wokwi: # Link to the Wokwi project if you're submitting for Hacky Holidays
---

# YOUR PROJECT NAME

<!-- Describe your board in 2-3 sentences. What are you making? What will it do? -->
"A Simple L298N Module for my Arduino Car"
<!-- How much is it going to cost? -->
"$10"
<!-- Tell us a little bit about your design process. What were some challenges? What helped? ***Totally optional*** -->
